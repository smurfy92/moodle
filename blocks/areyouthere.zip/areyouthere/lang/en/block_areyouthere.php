<?php
$string['pluginname'] = 'Areyouthere';